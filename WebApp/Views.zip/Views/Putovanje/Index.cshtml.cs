using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace WebApp.Views.Putovanje
{
    public class IndexModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
